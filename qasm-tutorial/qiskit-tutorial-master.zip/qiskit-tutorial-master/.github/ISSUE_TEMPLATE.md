<!--- Before submitting an issue, please check the Wiki for frequent issues:
https://github.com/QISKit/qiskit-tutorial/wiki/QISKit-Tutorials
-->

## Description
<!--- Please include information about the issue you are experiencing -->

## Your Environment
<!--- Please fill the following fields, and include any other information
about your environment that might be relevant. -->
* Tutorial branch (stable/master):
* QISKit SDK version:
* Python version:
